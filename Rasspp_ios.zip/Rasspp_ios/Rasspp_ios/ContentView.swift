import SwiftUI
import WebKit

struct ContentView: View {
    @State private var mostrarWeb = false
    @State private var animarLogo = false
    
    // ESTADOS PARA LA CÁMARA Y FOTO DE PERFIL REAL (CONEXIÓN CLOUDINARY)
    @State private var mostrarOpcionesFoto = false
    @State private var mostrarPicker = false
    @State private var tipoFuente: UIImagePickerController.SourceType = .photoLibrary
    @State private var imagenPerfil: UIImage? = nil
    @State private var subiendoACloudinary = false
    @State private var urlFotoCloudinary = ""
    
    // PALETA DE COLORES INSTITUCIONAL (La Salle)
    let azulLaSalle = Color(red: 0.02, green: 0.16, blue: 0.38) // #052861
    let rojoLaSalle = Color(red: 0.85, green: 0.11, blue: 0.17) // #D91C2B
    let fondoClaro = Color(red: 0.96, green: 0.97, blue: 0.99)
    
    var body: some View {
        ZStack {
            if mostrarWeb {
                // PANTALLA 2: EL WEBVIEW DE RASSPP
                NavigationStack {
                    WebViewInstitucional(url: URL(string: "https://rasspp-frontend.vercel.app")!)
                        .edgesIgnoringSafeArea(.bottom)
                        .navigationTitle("Portal RASSPP")
                        .navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .navigationBarLeading) {
                                Button(action: { withAnimation { mostrarWeb = false } }) {
                                    HStack(spacing: 5) {
                                        Image(systemName: "chevron.left")
                                        Text("Volver")
                                    }
                                    .fontWeight(.semibold)
                                    .foregroundColor(azulLaSalle)
                                }
                            }
                        }
                }
                .transition(.move(edge: .trailing))
            } else {
                // PANTALLA 1: LANDING PAGE CON DISEÑO PREMIUM CORREGIDO
                renderLandingPage()
                    .transition(.move(edge: .leading))
            }
        }
        // Menú nativo de iOS (Action Sheet) al presionar la foto de perfil - INTACTO
        .confirmationDialog("Gestionar Foto de Perfil", isPresented: $mostrarOpcionesFoto, titleVisibility: .visible) {
            Button("Tomar Foto con Cámara") {
                tipoFuente = .camera
                mostrarPicker = true
            }
            Button("Seleccionar de Galería") {
                tipoFuente = .photoLibrary
                mostrarPicker = true
            }
            if imagenPerfil != nil {
                Button("Eliminar Foto", role: .destructive) {
                    withAnimation {
                        imagenPerfil = nil
                        urlFotoCloudinary = ""
                    }
                }
            }
            Button("Cancelar", role: .cancel) {}
        }
        // Abre la cámara o galería del iPhone de forma segura
        .sheet(isPresented: $mostrarPicker, onDismiss: {
            DispatchQueue.main.async {
                subirFotoACloudinaryReal()
            }
        }) {
            if tipoFuente == .camera && !UIImagePickerController.isSourceTypeAvailable(.camera) {
                VStack(spacing: 20) {
                    Image(systemName: "camera.badge.ellipsis")
                        .font(.largeTitle)
                        .foregroundColor(.gray)
                    Text("La cámara no está disponible en este dispositivo.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Button("Entendido") {
                        mostrarPicker = false
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(azulLaSalle)
                }
                .padding()
            } else {
                ImagePicker(image: $imagenPerfil, sourceType: tipoFuente)
                    .ignoresSafeArea()
            }
        }
    }
    
    // MARK: - DISEÑO DE LA PANTALLA DE ENTRADA (LANDING PAGE - OPTIMIZADO)
    @ViewBuilder
    func renderLandingPage() -> some View {
        ZStack {
            // --- FONDO PREMIUM LIMPIO ---
            Color.white
                .ignoresSafeArea()
            
            // Efecto Glow sutil en la parte inferior para profundidad
            VStack {
                Spacer()
                Circle()
                    .fill(azulLaSalle.opacity(0.04))
                    .frame(width: 320, height: 320)
                    .blur(radius: 65)
                    .offset(y: 120)
            }
            .ignoresSafeArea()
            
            // CAPA SUPERIOR: AVATAR ESTILO GOOGLE (Esquina superior derecha)
            VStack {
                HStack {
                    Spacer()
                    
                    Button(action: { mostrarOpcionesFoto = true }) {
                        ZStack {
                            if subiendoACloudinary {
                                Circle()
                                    .frame(width: 46, height: 46)
                                    .foregroundColor(azulLaSalle.opacity(0.1))
                                ProgressView()
                                    .scaleEffect(0.9)
                                    .progressViewStyle(CircularProgressViewStyle(tint: azulLaSalle))
                            } else if let foto = imagenPerfil {
                                Image(uiImage: foto)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 44, height: 44)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(azulLaSalle, lineWidth: 2))
                                    .shadow(color: azulLaSalle.opacity(0.2), radius: 6, x: 0, y: 3)
                            } else {
                                Image(systemName: "person.crop.circle.fill")
                                    .font(.system(size: 42))
                                    .foregroundStyle(
                                        LinearGradient(colors: [azulLaSalle, azulLaSalle.opacity(0.8)], startPoint: .top, endPoint: .bottom)
                                    )
                                    .frame(width: 46, height: 46)
                                    .shadow(color: azulLaSalle.opacity(0.15), radius: 4, x: 0, y: 2)
                            }
                        }
                    }
                    .padding(.trailing, 24)
                    .padding(.top, 16)
                }
                Spacer()
            }
            
            // CONTENIDO CENTRAL
            VStack(spacing: 45) {
                Spacer()
                
                VStack(spacing: 24) {
                    Image("LogoApp")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 145, height: 145)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 34, style: .continuous)
                                .stroke(azulLaSalle.opacity(0.12), lineWidth: 1.5)
                        )
                        .shadow(color: azulLaSalle.opacity(0.12), radius: 18, x: 0, y: 10)
                        .scaleEffect(animarLogo ? 1.0 : 0.8)
                        .opacity(animarLogo ? 1.0 : 0.0)
                    
                    VStack(spacing: 12) {
                        Text("RASSPP")
                            .font(.system(size: 46, weight: .black, design: .rounded))
                            .tracking(3)
                            .foregroundStyle(
                                LinearGradient(colors: [azulLaSalle, azulLaSalle.opacity(0.85)], startPoint: .top, endPoint: .bottom)
                            )
                        
                        // --- CAMBIO DE COLOR SOLICITADO AQUÍ ---
                        Text("Gestión de Prácticas y Servicio Social")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(colors: [azulLaSalle, azulLaSalle.opacity(0.85)], startPoint: .top, endPoint: .bottom)
                            )
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 25)
                    }
                }
                
                Spacer()
                
                // --- BOTÓN ENTRAR ESTILO CRISTAL PREMIUM ---
                Button(action: {
                    withAnimation(.spring(response: 0.45, dampingFraction: 0.7)) {
                        mostrarWeb = true
                    }
                }) {
                    HStack(spacing: 12) {
                        Text("Entrar a la Aplicación")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                        Image(systemName: "arrow.right.circle.fill")
                            .font(.title3)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 62)
                    .background(
                        ZStack {
                            RoundedRectangle(cornerRadius: 22, style: .continuous)
                                .fill(LinearGradient(
                                    colors: [azulLaSalle, azulLaSalle.opacity(0.9)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                ))
                            
                            RoundedRectangle(cornerRadius: 22, style: .continuous)
                                .stroke(Color.white.opacity(0.12), lineWidth: 1)
                                .blur(radius: 1)
                            
                            VStack {
                                Spacer()
                                HStack {
                                    Spacer()
                                    Circle()
                                        .fill(rojoLaSalle.opacity(0.1))
                                        .frame(width: 80, height: 80)
                                        .blur(radius: 20)
                                        .offset(x: 30, y: 30)
                                }
                            }
                            .clipShape(RoundedRectangle(cornerRadius: 22))
                        }
                    )
                    .shadow(color: azulLaSalle.opacity(0.35), radius: 15, x: 0, y: 8)
                }
                .padding(.horizontal, 28)
                
                // Footer Institucional
                VStack(spacing: 6) {
                    HStack(spacing: 4) {
                        Text("Universidad de La Salle")
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundColor(azulLaSalle.opacity(0.8))
                        Circle()
                            .fill(rojoLaSalle)
                            .frame(width: 5, height: 5)
                    }
                    Text("Proyecto Integrador • Ingeniería de Software 4to Semestre")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundColor(.secondary.opacity(0.7))
                }
                .padding(.bottom, 10)
            }
            .padding()
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.8)) {
                animarLogo = true
            }
        }
    }
    
    // MARK: - CONEXIÓN CLOUDINARY (INTACTA)
    func subirFotoACloudinaryReal() {
        guard let fotoReal = imagenPerfil else { return }
        guard let datosImagen = fotoReal.jpegData(compressionQuality: 0.7) else { return }
        
        withAnimation { subiendoACloudinary = true }
        
        let cloudName = "dfcz12ilz"
        let uploadPreset = "rasspp_preset"
        let urlAPI = URL(string: "https://api.cloudinary.com/v1_1/\(cloudName)/image/upload")!
        
        var peticion = URLRequest(url: urlAPI)
        peticion.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        peticion.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var cuerpo = Data()
        cuerpo.append("--\(boundary)\r\n".data(using: .utf8)!)
        cuerpo.append("Content-Disposition: form-data; name=\"upload_preset\"\r\n\r\n".data(using: .utf8)!)
        cuerpo.append("\(uploadPreset)\r\n".data(using: .utf8)!)
        cuerpo.append("--\(boundary)\r\n".data(using: .utf8)!)
        cuerpo.append("Content-Disposition: form-data; name=\"file\"; filename=\"foto_perfil.jpg\"\r\n".data(using: .utf8)!)
        cuerpo.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
        cuerpo.append(datosImagen)
        cuerpo.append("\r\n".data(using: .utf8)!)
        cuerpo.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        peticion.httpBody = cuerpo
        
        URLSession.shared.dataTask(with: peticion) { datos, respuesta, error in
            DispatchQueue.main.async { withAnimation { self.subiendoACloudinary = false } }
            if let datos = datos {
                if let json = try? JSONSerialization.jsonObject(with: datos, options: []) as? [String: Any],
                   let urlPublica = json["secure_url"] as? String {
                    DispatchQueue.main.async {
                        self.urlFotoCloudinary = urlPublica
                        print("¡ÉXITO! URL: \(urlPublica)")
                    }
                }
            }
        }.resume()
    }
}

struct WebViewInstitucional: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.allowsBackForwardNavigationGestures = true
        return webView
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.load(URLRequest(url: url))
    }
}
